def print_hello():
    print("Hello from libpp ....")